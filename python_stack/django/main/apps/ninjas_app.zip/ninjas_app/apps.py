from django.apps import AppConfig


class NinjasAppConfig(AppConfig):
    name = 'ninjas_app'
