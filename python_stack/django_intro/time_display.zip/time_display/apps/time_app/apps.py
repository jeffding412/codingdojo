from django.apps import AppConfig


class TimeAppConfig(AppConfig):
    name = 'time_app'
