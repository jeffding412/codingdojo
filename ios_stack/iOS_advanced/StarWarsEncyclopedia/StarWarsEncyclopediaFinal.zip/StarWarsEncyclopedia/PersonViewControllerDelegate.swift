//
//  PersonViewControllerDelegate.swift
//  StarWarsEncyclopedia
//
//  Created by Jeffrey Ding on 9/17/18.
//  Copyright © 2018 Jeffrey Ding. All rights reserved.
//

import UIKit

protocol PersonViewControllerDelegate: class {
    
}
